import { IsOptional, IsString } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationDto } from '../../common/dto/pagination.dto';

export class QueryDeviceDto extends PaginationDto {
  @ApiPropertyOptional({
    description: 'Filter by device type',
    example: 'mobile',
  })
  @IsOptional()
  @IsString()
  type?: string;

  @ApiPropertyOptional({
    description: 'Filter by manufacturer',
    example: 'Apple',
  })
  @IsOptional()
  @IsString()
  manufacturer?: string;

  @ApiPropertyOptional({
    description: 'Filter by operating system',
    example: 'iOS',
  })
  @IsOptional()
  @IsString()
  os?: string;

  @ApiPropertyOptional({
    description: 'Filter by browser',
    example: 'Safari',
  })
  @IsOptional()
  @IsString()
  browser?: string;
}
