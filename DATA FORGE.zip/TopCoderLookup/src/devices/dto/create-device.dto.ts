import {
  IsString,
  IsNotEmpty,
  IsOptional,
  IsInt,
  Length,
  Min,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class CreateDeviceDto {
  @ApiProperty({
    description: 'Device type',
    example: 'mobile',
    enum: ['mobile', 'desktop', 'tablet', 'tv', 'watch', 'console'],
  })
  @IsString()
  @IsNotEmpty()
  type: string;

  @ApiPropertyOptional({
    description: 'Device manufacturer',
    example: 'Apple',
  })
  @IsOptional()
  @IsString()
  @Length(1, 100)
  manufacturer?: string;

  @ApiPropertyOptional({
    description: 'Device model',
    example: 'iPhone 15 Pro',
  })
  @IsOptional()
  @IsString()
  @Length(1, 100)
  model?: string;

  @ApiPropertyOptional({
    description: 'Operating system',
    example: 'iOS',
  })
  @IsOptional()
  @IsString()
  @Length(1, 50)
  os?: string;

  @ApiPropertyOptional({
    description: 'Operating system version',
    example: '17.0',
  })
  @IsOptional()
  @IsString()
  @Length(1, 20)
  osVersion?: string;

  @ApiPropertyOptional({
    description: 'Browser name',
    example: 'Safari',
  })
  @IsOptional()
  @IsString()
  @Length(1, 50)
  browser?: string;

  @ApiPropertyOptional({
    description: 'Browser version',
    example: '17.0',
  })
  @IsOptional()
  @IsString()
  @Length(1, 20)
  browserVersion?: string;

  @ApiPropertyOptional({
    description: 'Screen width in pixels',
    example: 393,
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  screenWidth?: number;

  @ApiPropertyOptional({
    description: 'Screen height in pixels',
    example: 852,
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  screenHeight?: number;

  @ApiPropertyOptional({
    description: 'User agent string',
    example: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15',
  })
  @IsOptional()
  @IsString()
  userAgent?: string;
}
