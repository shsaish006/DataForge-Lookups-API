import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Device as PrismaDevice } from '@prisma/client';

export class Device implements PrismaDevice {
  @ApiProperty({
    description: 'Unique identifier',
    example: 'clq2j9x8r0000356lz8q9x8r0',
  })
  id: string;

  @ApiProperty({
    description: 'Device type',
    example: 'mobile',
  })
  type: string;

  @ApiPropertyOptional({
    description: 'Device manufacturer',
    example: 'Apple',
  })
  manufacturer: string | null;

  @ApiPropertyOptional({
    description: 'Device model',
    example: 'iPhone 15 Pro',
  })
  model: string | null;

  @ApiPropertyOptional({
    description: 'Operating system',
    example: 'iOS',
  })
  os: string | null;

  @ApiPropertyOptional({
    description: 'Operating system version',
    example: '17.0',
  })
  osVersion: string | null;

  @ApiPropertyOptional({
    description: 'Browser name',
    example: 'Safari',
  })
  browser: string | null;

  @ApiPropertyOptional({
    description: 'Browser version',
    example: '17.0',
  })
  browserVersion: string | null;

  @ApiPropertyOptional({
    description: 'Screen width in pixels',
    example: 393,
  })
  screenWidth: number | null;

  @ApiPropertyOptional({
    description: 'Screen height in pixels',
    example: 852,
  })
  screenHeight: number | null;

  @ApiPropertyOptional({
    description: 'User agent string',
    example: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15',
  })
  userAgent: string | null;

  @ApiProperty({
    description: 'Creation timestamp',
  })
  createdAt: Date;

  @ApiProperty({
    description: 'Last update timestamp',
  })
  updatedAt: Date;

  @ApiPropertyOptional({
    description: 'User who created the record',
  })
  createdBy: string | null;

  @ApiPropertyOptional({
    description: 'User who last updated the record',
  })
  updatedBy: string | null;
}
