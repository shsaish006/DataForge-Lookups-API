import { IsOptional, IsString } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationDto } from '../../common/dto/pagination.dto';

export class QueryCountryDto extends PaginationDto {
  @ApiPropertyOptional({
    description: 'Filter by country code',
    example: 'US',
  })
  @IsOptional()
  @IsString()
  countryCode?: string;
}
