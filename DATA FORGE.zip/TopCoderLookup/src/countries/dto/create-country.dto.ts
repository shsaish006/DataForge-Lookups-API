import { IsString, IsNotEmpty, IsOptional, Length } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Transform } from 'class-transformer';

export class CreateCountryDto {
  @ApiProperty({
    description: 'Country name',
    example: 'United States',
  })
  @IsString()
  @IsNotEmpty()
  @Length(1, 255)
  name: string;

  @ApiProperty({
    description: 'ISO country code',
    example: 'US',
  })
  @IsString()
  @IsNotEmpty()
  @Length(2, 3)
  @Transform(({ value }) => value?.toUpperCase())
  countryCode: string;

  @ApiPropertyOptional({
    description: 'Country flag emoji',
    example: '🇺🇸',
  })
  @IsOptional()
  @IsString()
  countryFlag?: string;
}
