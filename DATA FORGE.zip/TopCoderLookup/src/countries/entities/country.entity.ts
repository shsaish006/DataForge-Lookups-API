import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Country as PrismaCountry } from '@prisma/client';

export class Country implements PrismaCountry {
  @ApiProperty({
    description: 'Unique identifier',
    example: 'clq2j9x8r0000356lz8q9x8r0',
  })
  id: string;

  @ApiProperty({
    description: 'Country name',
    example: 'United States',
  })
  name: string;

  @ApiProperty({
    description: 'ISO country code',
    example: 'US',
  })
  countryCode: string;

  @ApiPropertyOptional({
    description: 'Country flag emoji',
    example: '🇺🇸',
  })
  countryFlag: string | null;

  @ApiProperty({
    description: 'Creation timestamp',
  })
  createdAt: Date;

  @ApiProperty({
    description: 'Last update timestamp',
  })
  updatedAt: Date;

  @ApiPropertyOptional({
    description: 'User who created the record',
  })
  createdBy: string | null;

  @ApiPropertyOptional({
    description: 'User who last updated the record',
  })
  updatedBy: string | null;
}
