import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class AdminGuard implements CanActivate {
  constructor(private configService: ConfigService) {}

  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const user = request.user;

    if (!user) {
      throw new ForbiddenException('No user context found');
    }

    const adminUsers = this.configService.get<string[]>('auth.adminUsers') || [];
    const m2mClientIds = this.configService.get<string[]>('auth.m2mClientIds') || [];

    // Check if user is admin
    if (user.email && adminUsers.includes(user.email)) {
      return true;
    }

    // Check if it's an M2M client
    if (user.clientId && m2mClientIds.includes(user.clientId)) {
      return true;
    }

    // Check if user has admin role
    if (user.roles && user.roles.includes('admin')) {
      return true;
    }

    throw new ForbiddenException('Admin access required');
  }
}
