import { registerAs } from '@nestjs/config';

export default registerAs('auth', () => ({
  jwtSecret: process.env.JWT_SECRET || 'fallback-secret-key',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '24h',
  adminUsers: process.env.ADMIN_USERS?.split(',') || [],
  m2mClientIds: process.env.M2M_CLIENT_IDS?.split(',') || [],
}));
