import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';

export interface JwtPayload {
  sub: string;
  email?: string;
  clientId?: string;
  roles?: string[];
  iat?: number;
  exp?: number;
}

@Injectable()
export class AuthService {
  constructor(private jwtService: JwtService) {}

  async validateUser(payload: JwtPayload): Promise<any> {
    // In a real implementation, you would validate the user against your user database
    // For now, we'll return the payload as the user object
    return {
      id: payload.sub,
      email: payload.email,
      clientId: payload.clientId,
      roles: payload.roles || [],
    };
  }

  async generateToken(payload: JwtPayload): Promise<string> {
    return this.jwtService.sign(payload);
  }

  async verifyToken(token: string): Promise<JwtPayload> {
    return this.jwtService.verify(token);
  }
}
