import { IsOptional, IsString } from 'class-validator';
import { ApiPropertyOptional } from '@nestjs/swagger';
import { PaginationDto } from '../../common/dto/pagination.dto';

export class QueryEducationalInstitutionDto extends PaginationDto {
  @ApiPropertyOptional({
    description: 'Filter by country ID',
    example: 'clq2j9x8r0000356lz8q9x8r0',
  })
  @IsOptional()
  @IsString()
  countryId?: string;

  @ApiPropertyOptional({
    description: 'Filter by state',
    example: 'Massachusetts',
  })
  @IsOptional()
  @IsString()
  state?: string;

  @ApiPropertyOptional({
    description: 'Filter by city',
    example: 'Cambridge',
  })
  @IsOptional()
  @IsString()
  city?: string;

  @ApiPropertyOptional({
    description: 'Filter by institution type',
    example: 'private',
  })
  @IsOptional()
  @IsString()
  type?: string;
}
