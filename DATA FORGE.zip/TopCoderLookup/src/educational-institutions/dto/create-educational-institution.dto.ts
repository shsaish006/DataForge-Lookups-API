import {
  IsString,
  IsNotEmpty,
  IsOptional,
  IsInt,
  IsUrl,
  Length,
  Min,
  Max,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class CreateEducationalInstitutionDto {
  @ApiProperty({
    description: 'Institution name',
    example: 'Massachusetts Institute of Technology',
  })
  @IsString()
  @IsNotEmpty()
  @Length(1, 255)
  name: string;

  @ApiProperty({
    description: 'Country ID',
    example: 'clq2j9x8r0000356lz8q9x8r0',
  })
  @IsString()
  @IsNotEmpty()
  countryId: string;

  @ApiPropertyOptional({
    description: 'State or province',
    example: 'Massachusetts',
  })
  @IsOptional()
  @IsString()
  @Length(1, 100)
  state?: string;

  @ApiPropertyOptional({
    description: 'City',
    example: 'Cambridge',
  })
  @IsOptional()
  @IsString()
  @Length(1, 100)
  city?: string;

  @ApiPropertyOptional({
    description: 'Institution website',
    example: 'https://www.mit.edu',
  })
  @IsOptional()
  @IsUrl()
  website?: string;

  @ApiPropertyOptional({
    description: 'Year established',
    example: 1861,
  })
  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1000)
  @Max(new Date().getFullYear())
  established?: number;

  @ApiPropertyOptional({
    description: 'Institution type',
    example: 'private',
    enum: ['public', 'private', 'non-profit', 'for-profit'],
  })
  @IsOptional()
  @IsString()
  type?: string;
}
