import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { EducationalInstitution as PrismaEducationalInstitution } from '@prisma/client';

export class EducationalInstitution implements PrismaEducationalInstitution {
  @ApiProperty({
    description: 'Unique identifier',
    example: 'clq2j9x8r0000356lz8q9x8r0',
  })
  id: string;

  @ApiProperty({
    description: 'Institution name',
    example: 'Massachusetts Institute of Technology',
  })
  name: string;

  @ApiProperty({
    description: 'Country ID',
    example: 'clq2j9x8r0000356lz8q9x8r0',
  })
  countryId: string;

  @ApiPropertyOptional({
    description: 'State or province',
    example: 'Massachusetts',
  })
  state: string | null;

  @ApiPropertyOptional({
    description: 'City',
    example: 'Cambridge',
  })
  city: string | null;

  @ApiPropertyOptional({
    description: 'Institution website',
    example: 'https://www.mit.edu',
  })
  website: string | null;

  @ApiPropertyOptional({
    description: 'Year established',
    example: 1861,
  })
  established: number | null;

  @ApiPropertyOptional({
    description: 'Institution type',
    example: 'private',
  })
  type: string | null;

  @ApiProperty({
    description: 'Creation timestamp',
  })
  createdAt: Date;

  @ApiProperty({
    description: 'Last update timestamp',
  })
  updatedAt: Date;

  @ApiPropertyOptional({
    description: 'User who created the record',
  })
  createdBy: string | null;

  @ApiPropertyOptional({
    description: 'User who last updated the record',
  })
  updatedBy: string | null;
}
