import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // Seed Countries
  const countries = [
    {
      name: 'United States',
      countryCode: 'US',
      countryFlag: '🇺🇸',
    },
    {
      name: 'Canada',
      countryCode: 'CA',
      countryFlag: '🇨🇦',
    },
    {
      name: 'United Kingdom',
      countryCode: 'GB',
      countryFlag: '🇬🇧',
    },
    {
      name: 'Germany',
      countryCode: 'DE',
      countryFlag: '🇩🇪',
    },
    {
      name: 'France',
      countryCode: 'FR',
      countryFlag: '🇫🇷',
    },
    {
      name: 'Japan',
      countryCode: 'JP',
      countryFlag: '🇯🇵',
    },
    {
      name: 'Australia',
      countryCode: 'AU',
      countryFlag: '🇦🇺',
    },
    {
      name: 'India',
      countryCode: 'IN',
      countryFlag: '🇮🇳',
    },
  ];

  console.log('Creating countries...');
  const createdCountries = [];
  for (const countryData of countries) {
    const country = await prisma.country.upsert({
      where: { countryCode: countryData.countryCode },
      update: {},
      create: countryData,
    });
    createdCountries.push(country);
    console.log(`✅ Created country: ${country.name}`);
  }

  // Seed Educational Institutions
  const institutions = [
    {
      name: 'Massachusetts Institute of Technology',
      countryId: createdCountries.find(c => c.countryCode === 'US')?.id || '',
      state: 'Massachusetts',
      city: 'Cambridge',
      website: 'https://www.mit.edu',
      established: 1861,
      type: 'private',
    },
    {
      name: 'Harvard University',
      countryId: createdCountries.find(c => c.countryCode === 'US')?.id || '',
      state: 'Massachusetts',
      city: 'Cambridge',
      website: 'https://www.harvard.edu',
      established: 1636,
      type: 'private',
    },
    {
      name: 'University of Toronto',
      countryId: createdCountries.find(c => c.countryCode === 'CA')?.id || '',
      state: 'Ontario',
      city: 'Toronto',
      website: 'https://www.utoronto.ca',
      established: 1827,
      type: 'public',
    },
    {
      name: 'University of Oxford',
      countryId: createdCountries.find(c => c.countryCode === 'GB')?.id || '',
      state: 'England',
      city: 'Oxford',
      website: 'https://www.ox.ac.uk',
      established: 1096,
      type: 'public',
    },
    {
      name: 'Technical University of Munich',
      countryId: createdCountries.find(c => c.countryCode === 'DE')?.id || '',
      state: 'Bavaria',
      city: 'Munich',
      website: 'https://www.tum.de',
      established: 1868,
      type: 'public',
    },
  ];

  console.log('Creating educational institutions...');
  for (const institutionData of institutions) {
    // Check if institution already exists by name
    const existingInstitution = await prisma.educationalInstitution.findFirst({
      where: { name: institutionData.name }
    });
    
    if (!existingInstitution) {
      const institution = await prisma.educationalInstitution.create({
        data: institutionData,
      });
      console.log(`✅ Created institution: ${institution.name}`);
    } else {
      console.log(`⏭️  Institution already exists: ${institutionData.name}`);
    }
  }

  // Seed Devices
  const devices = [
    {
      type: 'mobile',
      manufacturer: 'Apple',
      model: 'iPhone 15 Pro',
      os: 'iOS',
      osVersion: '17.0',
      browser: 'Safari',
      browserVersion: '17.0',
      screenWidth: 393,
      screenHeight: 852,
      userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15',
    },
    {
      type: 'mobile',
      manufacturer: 'Samsung',
      model: 'Galaxy S24',
      os: 'Android',
      osVersion: '14',
      browser: 'Chrome',
      browserVersion: '120.0',
      screenWidth: 360,
      screenHeight: 800,
      userAgent: 'Mozilla/5.0 (Linux; Android 14; SM-S921B) AppleWebKit/537.36',
    },
    {
      type: 'desktop',
      manufacturer: 'Dell',
      model: 'XPS 13',
      os: 'Windows',
      osVersion: '11',
      browser: 'Chrome',
      browserVersion: '120.0',
      screenWidth: 1920,
      screenHeight: 1080,
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    },
    {
      type: 'tablet',
      manufacturer: 'Apple',
      model: 'iPad Pro',
      os: 'iPadOS',
      osVersion: '17.0',
      browser: 'Safari',
      browserVersion: '17.0',
      screenWidth: 1024,
      screenHeight: 1366,
      userAgent: 'Mozilla/5.0 (iPad; CPU OS 17_0 like Mac OS X) AppleWebKit/605.1.15',
    },
    {
      type: 'desktop',
      manufacturer: 'Apple',
      model: 'MacBook Pro',
      os: 'macOS',
      osVersion: '14.0',
      browser: 'Safari',
      browserVersion: '17.0',
      screenWidth: 2560,
      screenHeight: 1600,
      userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15',
    },
  ];

  console.log('Creating devices...');
  for (const deviceData of devices) {
    const device = await prisma.device.create({
      data: deviceData,
    });
    console.log(`✅ Created device: ${device.manufacturer} ${device.model}`);
  }

  console.log('🎉 Seeding completed successfully!');
}

main()
  .catch((e) => {
    console.error('❌ Seeding failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
