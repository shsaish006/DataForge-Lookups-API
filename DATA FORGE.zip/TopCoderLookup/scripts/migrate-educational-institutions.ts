import { Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { DynamoDBClient, ScanCommand } from '@aws-sdk/client-dynamodb';
import { unmarshall } from '@aws-sdk/util-dynamodb';

const logger = new Logger('EducationalInstitutionsMigration');
const prisma = new PrismaClient();

const dynamoClient = new DynamoDBClient({
  region: process.env.DYNAMODB_REGION || 'us-east-1',
  credentials: {
    accessKeyId: process.env.DYNAMODB_ACCESS_KEY_ID || '',
    secretAccessKey: process.env.DYNAMODB_SECRET_ACCESS_KEY || '',
  },
});

interface DynamoEducationalInstitution {
  id: string;
  name: string;
  countryId?: string;
  countryCode?: string;
  state?: string;
  city?: string;
  website?: string;
  established?: number;
  type?: string;
  createdAt?: string;
  updatedAt?: string;
  createdBy?: string;
  updatedBy?: string;
}

export async function migrateEducationalInstitutions(): Promise<void> {
  logger.log('Starting educational institutions migration from DynamoDB...');

  try {
    // Get country mapping for foreign key relationships
    const countryMapping = await getCountryMapping();
    logger.log(`Loaded ${Object.keys(countryMapping).length} countries for mapping`);

    // Scan all educational institutions from DynamoDB
    const institutions = await scanDynamoEducationalInstitutions();
    logger.log(`Found ${institutions.length} educational institutions in DynamoDB`);

    if (institutions.length === 0) {
      logger.warn('No educational institutions found in DynamoDB');
      return;
    }

    // Migrate each institution to PostgreSQL
    let migratedCount = 0;
    let skippedCount = 0;
    let errorCount = 0;

    for (const institution of institutions) {
      try {
        await migrateEducationalInstitution(institution, countryMapping);
        migratedCount++;
        logger.log(`✅ Migrated: ${institution.name}`);
      } catch (error) {
        if (error.code === 'P2002') {
          skippedCount++;
          logger.warn(`⚠️ Skipped (already exists): ${institution.name}`);
        } else if (error.code === 'P2003') {
          errorCount++;
          logger.error(`❌ Foreign key constraint failed for ${institution.name}: Invalid country reference`);
        } else {
          errorCount++;
          logger.error(`❌ Failed to migrate ${institution.name}: ${error.message}`);
        }
      }
    }

    logger.log(`Educational institutions migration summary:`);
    logger.log(`  - Migrated: ${migratedCount}`);
    logger.log(`  - Skipped: ${skippedCount}`);
    logger.log(`  - Errors: ${errorCount}`);
    logger.log(`  - Total processed: ${institutions.length}`);

  } catch (error) {
    logger.error('Educational institutions migration failed:', error);
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

async function getCountryMapping(): Promise<Record<string, string>> {
  const countries = await prisma.country.findMany({
    select: { id: true, countryCode: true, name: true },
  });

  const mapping: Record<string, string> = {};
  
  for (const country of countries) {
    // Map by country code
    mapping[country.countryCode] = country.id;
    // Map by country name (case-insensitive)
    mapping[country.name.toLowerCase()] = country.id;
  }

  return mapping;
}

async function scanDynamoEducationalInstitutions(): Promise<DynamoEducationalInstitution[]> {
  const institutions: DynamoEducationalInstitution[] = [];
  let lastEvaluatedKey: any = undefined;

  do {
    const command = new ScanCommand({
      TableName: 'EducationalInstitutions', // Adjust table name as needed
      ExclusiveStartKey: lastEvaluatedKey,
    });

    const response = await dynamoClient.send(command);

    if (response.Items) {
      const batchInstitutions = response.Items.map(item => {
        const unmarshalled = unmarshall(item);
        return {
          id: unmarshalled.id || unmarshalled.pk || generateId(),
          name: unmarshalled.name,
          countryId: unmarshalled.countryId,
          countryCode: unmarshalled.countryCode || unmarshalled.country,
          state: unmarshalled.state || unmarshalled.province,
          city: unmarshalled.city,
          website: unmarshalled.website || unmarshalled.url,
          established: unmarshalled.established ? parseInt(unmarshalled.established) : undefined,
          type: unmarshalled.type || unmarshalled.institutionType,
          createdAt: unmarshalled.createdAt,
          updatedAt: unmarshalled.updatedAt,
          createdBy: unmarshalled.createdBy,
          updatedBy: unmarshalled.updatedBy,
        };
      });

      institutions.push(...batchInstitutions);
    }

    lastEvaluatedKey = response.LastEvaluatedKey;
  } while (lastEvaluatedKey);

  return institutions;
}

async function migrateEducationalInstitution(
  institution: DynamoEducationalInstitution,
  countryMapping: Record<string, string>,
): Promise<void> {
  // Determine country ID
  let countryId = institution.countryId;
  
  if (!countryId && institution.countryCode) {
    countryId = countryMapping[institution.countryCode.toUpperCase()];
  }

  if (!countryId) {
    throw new Error(`Cannot determine country ID for institution: ${institution.name}`);
  }

  await prisma.educationalInstitution.create({
    data: {
      id: institution.id,
      name: institution.name,
      countryId,
      state: institution.state || null,
      city: institution.city || null,
      website: institution.website || null,
      established: institution.established || null,
      type: institution.type || null,
      createdAt: institution.createdAt ? new Date(institution.createdAt) : new Date(),
      updatedAt: institution.updatedAt ? new Date(institution.updatedAt) : new Date(),
      createdBy: institution.createdBy || 'migration',
      updatedBy: institution.updatedBy || 'migration',
    },
  });
}

function generateId(): string {
  return `institution_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// Allow running this script independently
if (require.main === module) {
  migrateEducationalInstitutions()
    .then(() => {
      logger.log('Educational institutions migration completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      logger.error('Educational institutions migration failed:', error);
      process.exit(1);
    });
}
