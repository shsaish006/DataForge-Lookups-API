import { Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { DynamoDBClient, ScanCommand } from '@aws-sdk/client-dynamodb';
import { unmarshall } from '@aws-sdk/util-dynamodb';

const logger = new Logger('DevicesMigration');
const prisma = new PrismaClient();

const dynamoClient = new DynamoDBClient({
  region: process.env.DYNAMODB_REGION || 'us-east-1',
  credentials: {
    accessKeyId: process.env.DYNAMODB_ACCESS_KEY_ID || '',
    secretAccessKey: process.env.DYNAMODB_SECRET_ACCESS_KEY || '',
  },
});

interface DynamoDevice {
  id: string;
  type: string;
  manufacturer?: string;
  model?: string;
  os?: string;
  osVersion?: string;
  browser?: string;
  browserVersion?: string;
  screenWidth?: number;
  screenHeight?: number;
  userAgent?: string;
  createdAt?: string;
  updatedAt?: string;
  createdBy?: string;
  updatedBy?: string;
}

export async function migrateDevices(): Promise<void> {
  logger.log('Starting devices migration from DynamoDB...');

  try {
    // Scan all devices from DynamoDB
    const devices = await scanDynamoDevices();
    logger.log(`Found ${devices.length} devices in DynamoDB`);

    if (devices.length === 0) {
      logger.warn('No devices found in DynamoDB');
      return;
    }

    // Migrate each device to PostgreSQL
    let migratedCount = 0;
    let skippedCount = 0;
    let errorCount = 0;

    for (const device of devices) {
      try {
        await migrateDevice(device);
        migratedCount++;
        logger.log(`✅ Migrated: ${device.manufacturer} ${device.model} (${device.type})`);
      } catch (error) {
        if (error.code === 'P2002') {
          skippedCount++;
          logger.warn(`⚠️ Skipped (already exists): ${device.manufacturer} ${device.model}`);
        } else {
          errorCount++;
          logger.error(`❌ Failed to migrate ${device.manufacturer} ${device.model}: ${error.message}`);
        }
      }
    }

    logger.log(`Devices migration summary:`);
    logger.log(`  - Migrated: ${migratedCount}`);
    logger.log(`  - Skipped: ${skippedCount}`);
    logger.log(`  - Errors: ${errorCount}`);
    logger.log(`  - Total processed: ${devices.length}`);

  } catch (error) {
    logger.error('Devices migration failed:', error);
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

async function scanDynamoDevices(): Promise<DynamoDevice[]> {
  const devices: DynamoDevice[] = [];
  let lastEvaluatedKey: any = undefined;

  do {
    const command = new ScanCommand({
      TableName: 'Devices', // Adjust table name as needed
      ExclusiveStartKey: lastEvaluatedKey,
    });

    const response = await dynamoClient.send(command);

    if (response.Items) {
      const batchDevices = response.Items.map(item => {
        const unmarshalled = unmarshall(item);
        return {
          id: unmarshalled.id || unmarshalled.pk || generateId(),
          type: unmarshalled.type || unmarshalled.deviceType || 'unknown',
          manufacturer: unmarshalled.manufacturer || unmarshalled.brand,
          model: unmarshalled.model || unmarshalled.deviceModel,
          os: unmarshalled.os || unmarshalled.operatingSystem,
          osVersion: unmarshalled.osVersion || unmarshalled.os_version,
          browser: unmarshalled.browser || unmarshalled.browserName,
          browserVersion: unmarshalled.browserVersion || unmarshalled.browser_version,
          screenWidth: unmarshalled.screenWidth ? parseInt(unmarshalled.screenWidth) : undefined,
          screenHeight: unmarshalled.screenHeight ? parseInt(unmarshalled.screenHeight) : undefined,
          userAgent: unmarshalled.userAgent || unmarshalled.user_agent,
          createdAt: unmarshalled.createdAt,
          updatedAt: unmarshalled.updatedAt,
          createdBy: unmarshalled.createdBy,
          updatedBy: unmarshalled.updatedBy,
        };
      });

      devices.push(...batchDevices);
    }

    lastEvaluatedKey = response.LastEvaluatedKey;
  } while (lastEvaluatedKey);

  return devices;
}

async function migrateDevice(device: DynamoDevice): Promise<void> {
  await prisma.device.create({
    data: {
      id: device.id,
      type: device.type,
      manufacturer: device.manufacturer || null,
      model: device.model || null,
      os: device.os || null,
      osVersion: device.osVersion || null,
      browser: device.browser || null,
      browserVersion: device.browserVersion || null,
      screenWidth: device.screenWidth || null,
      screenHeight: device.screenHeight || null,
      userAgent: device.userAgent || null,
      createdAt: device.createdAt ? new Date(device.createdAt) : new Date(),
      updatedAt: device.updatedAt ? new Date(device.updatedAt) : new Date(),
      createdBy: device.createdBy || 'migration',
      updatedBy: device.updatedBy || 'migration',
    },
  });
}

function generateId(): string {
  return `device_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// Allow running this script independently
if (require.main === module) {
  migrateDevices()
    .then(() => {
      logger.log('Devices migration completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      logger.error('Devices migration failed:', error);
      process.exit(1);
    });
}
