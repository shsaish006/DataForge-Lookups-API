#!/usr/bin/env ts-node

/**
 * Main data migration script for migrating data from DynamoDB to PostgreSQL
 * This script orchestrates the migration of all entity types
 */

import { Logger } from '@nestjs/common';
import { migrateCountries } from './migrate-countries';
import { migrateEducationalInstitutions } from './migrate-educational-institutions';
import { migrateDevices } from './migrate-devices';

const logger = new Logger('DataMigration');

async function main() {
  logger.log('🚀 Starting data migration from DynamoDB to PostgreSQL...');
  
  const startTime = Date.now();

  try {
    // Step 1: Migrate Countries (must be first due to foreign key constraints)
    logger.log('📍 Step 1: Migrating Countries...');
    await migrateCountries();
    logger.log('✅ Countries migration completed');

    // Step 2: Migrate Educational Institutions (depends on Countries)
    logger.log('🏫 Step 2: Migrating Educational Institutions...');
    await migrateEducationalInstitutions();
    logger.log('✅ Educational Institutions migration completed');

    // Step 3: Migrate Devices (independent)
    logger.log('📱 Step 3: Migrating Devices...');
    await migrateDevices();
    logger.log('✅ Devices migration completed');

    const endTime = Date.now();
    const duration = (endTime - startTime) / 1000;

    logger.log(`🎉 Data migration completed successfully in ${duration}s`);
    
  } catch (error) {
    logger.error('❌ Data migration failed:', error);
    process.exit(1);
  }
}

// Configuration validation
function validateConfiguration() {
  const requiredEnvVars = [
    'DATABASE_URL',
    'DYNAMODB_REGION',
    'DYNAMODB_ACCESS_KEY_ID',
    'DYNAMODB_SECRET_ACCESS_KEY',
  ];

  const missingVars = requiredEnvVars.filter(varName => !process.env[varName]);
  
  if (missingVars.length > 0) {
    logger.error(`Missing required environment variables: ${missingVars.join(', ')}`);
    logger.error('Please check your .env file and ensure all required variables are set');
    process.exit(1);
  }

  logger.log('✅ Configuration validation passed');
}

// Run migration with proper error handling
if (require.main === module) {
  validateConfiguration();
  main()
    .catch((error) => {
      logger.error('Unhandled error during migration:', error);
      process.exit(1);
    })
    .finally(() => {
      logger.log('Migration script finished');
      process.exit(0);
    });
}

export { main as runMigration };
