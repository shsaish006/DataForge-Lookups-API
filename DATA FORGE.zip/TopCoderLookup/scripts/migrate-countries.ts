import { Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { DynamoDBClient, ScanCommand } from '@aws-sdk/client-dynamodb';
import { unmarshall } from '@aws-sdk/util-dynamodb';

const logger = new Logger('CountriesMigration');
const prisma = new PrismaClient();

// DynamoDB configuration
const dynamoClient = new DynamoDBClient({
  region: process.env.DYNAMODB_REGION || 'us-east-1',
  credentials: {
    accessKeyId: process.env.DYNAMODB_ACCESS_KEY_ID || '',
    secretAccessKey: process.env.DYNAMODB_SECRET_ACCESS_KEY || '',
  },
});

interface DynamoCountry {
  id: string;
  name: string;
  countryCode: string;
  countryFlag?: string;
  createdAt?: string;
  updatedAt?: string;
  createdBy?: string;
  updatedBy?: string;
}

export async function migrateCountries(): Promise<void> {
  logger.log('Starting countries migration from DynamoDB...');

  try {
    // Scan all countries from DynamoDB
    const countries = await scanDynamoCountries();
    logger.log(`Found ${countries.length} countries in DynamoDB`);

    if (countries.length === 0) {
      logger.warn('No countries found in DynamoDB');
      return;
    }

    // Migrate each country to PostgreSQL
    let migratedCount = 0;
    let skippedCount = 0;
    let errorCount = 0;

    for (const country of countries) {
      try {
        await migrateCountry(country);
        migratedCount++;
        logger.log(`✅ Migrated: ${country.name} (${country.countryCode})`);
      } catch (error) {
        if (error.code === 'P2002') {
          // Unique constraint violation - country already exists
          skippedCount++;
          logger.warn(`⚠️ Skipped (already exists): ${country.name} (${country.countryCode})`);
        } else {
          errorCount++;
          logger.error(`❌ Failed to migrate ${country.name}: ${error.message}`);
        }
      }
    }

    logger.log(`Countries migration summary:`);
    logger.log(`  - Migrated: ${migratedCount}`);
    logger.log(`  - Skipped: ${skippedCount}`);
    logger.log(`  - Errors: ${errorCount}`);
    logger.log(`  - Total processed: ${countries.length}`);

  } catch (error) {
    logger.error('Countries migration failed:', error);
    throw error;
  } finally {
    await prisma.$disconnect();
  }
}

async function scanDynamoCountries(): Promise<DynamoCountry[]> {
  const countries: DynamoCountry[] = [];
  let lastEvaluatedKey: any = undefined;

  do {
    const command = new ScanCommand({
      TableName: 'Countries', // Adjust table name as needed
      ExclusiveStartKey: lastEvaluatedKey,
    });

    const response = await dynamoClient.send(command);

    if (response.Items) {
      const batchCountries = response.Items.map(item => {
        const unmarshalled = unmarshall(item);
        return {
          id: unmarshalled.id || unmarshalled.pk || generateId(),
          name: unmarshalled.name,
          countryCode: unmarshalled.countryCode || unmarshalled.code,
          countryFlag: unmarshalled.countryFlag || unmarshalled.flag,
          createdAt: unmarshalled.createdAt,
          updatedAt: unmarshalled.updatedAt,
          createdBy: unmarshalled.createdBy,
          updatedBy: unmarshalled.updatedBy,
        };
      });

      countries.push(...batchCountries);
    }

    lastEvaluatedKey = response.LastEvaluatedKey;
  } while (lastEvaluatedKey);

  return countries;
}

async function migrateCountry(country: DynamoCountry): Promise<void> {
  await prisma.country.create({
    data: {
      id: country.id,
      name: country.name,
      countryCode: country.countryCode.toUpperCase(),
      countryFlag: country.countryFlag || null,
      createdAt: country.createdAt ? new Date(country.createdAt) : new Date(),
      updatedAt: country.updatedAt ? new Date(country.updatedAt) : new Date(),
      createdBy: country.createdBy || 'migration',
      updatedBy: country.updatedBy || 'migration',
    },
  });
}

function generateId(): string {
  return `country_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

// Allow running this script independently
if (require.main === module) {
  migrateCountries()
    .then(() => {
      logger.log('Countries migration completed successfully');
      process.exit(0);
    })
    .catch((error) => {
      logger.error('Countries migration failed:', error);
      process.exit(1);
    });
}
